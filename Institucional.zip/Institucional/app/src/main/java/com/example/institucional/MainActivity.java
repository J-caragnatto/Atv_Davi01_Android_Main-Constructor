package com.example.institucional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView btn3;
    private TextView btn4;
    private TextView btn5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

            btn3 = findViewById(R.id.textID3);

            btn3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intecao = new Intent(MainActivity.this, Contatos.class);
                        startActivity(intecao);
                }
            });

            btn4 = findViewById(R.id.textID4);

            btn4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intecao = new Intent(MainActivity.this, Entregas.class);
                    startActivity(intecao);
                }
            });

            btn5 = findViewById(R.id.textID5);

            btn5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intecao = new Intent(MainActivity.this, Sobre.class);
                    startActivity(intecao);
             }
            });

    }
}
